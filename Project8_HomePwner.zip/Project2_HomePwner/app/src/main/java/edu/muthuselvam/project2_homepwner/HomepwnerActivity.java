package edu.muthuselvam.project2_homepwner;

import androidx.fragment.app.Fragment;

public class HomepwnerActivity extends SingleActivity {

    @Override
    protected Fragment createFragment(){
        return new HomePwnerFragment();
    }


}
