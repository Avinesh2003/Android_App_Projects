package edu.muthuselvam.project2_homepwner;



import android.content.Intent;

import androidx.fragment.app.Fragment;

public class ItemActivity  extends SingleFragmentActivity implements HomePwnerFragment.Callbacks, ItemFragment.Callbacks {
    @Override
    protected Fragment createFragment() {
        return new ItemFragment();
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_masterdetail;
    }

    @Override
    public void onItemSelected(Item item) {
        if (findViewById(R.id.detail_fragment_container) == null) {
            Intent intent = HomepwnerPagerActivity.newIntent(this, item.getId());
            startActivity(intent);
        } else {
            Fragment newDetail = HomePwnerFragment.newInstance(item.getId());
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.detail_fragment_container, newDetail)
                    .commit();
        }
    }

    public void onItemUpdated(Item item) {
        ItemFragment listFragment = (ItemFragment)
                getSupportFragmentManager()
                        .findFragmentById(R.id.fragment_container);
        listFragment.updateUI();
    }
}




