package edu.muthuselvam.project2_homepwner;

import java.util.Date;
import java.util.UUID;

public class Item {
    private UUID mId;
    private String mName;
    private String mValue;
    private Date mDate;
    private String mSerial;


    public static final String[] ITEM_NAMES = {"Rust Bear", "Fluffy Bear", "Fluffy Spork", "Shiny Mac", "Fluffy Toy"};
    public static final String[] ITEM_VALUES = {"$94", "$59", "$66", "$72", "$40"};

    public static final String[] ITEM_SERIAL = {"A3F4D2B1", "1E4C9A3D", "7B8E2C4F", "D9F4A2E6", "C3B7E1A4"};


    public Item() {
        mId = UUID.randomUUID();
        mDate = new Date();
    }

    // Getter for the item ID
    public UUID getId() {
        return mId;
    }

    // Getter for the item name
    public String getName() {
        return mName;
    }

    // Setter for the item name
    public void setName(String name) {
        mName = name;
    }

    // Getter for the item value
    public String getValue() {
        return mValue;
    }

    // Setter for the item value
    public void setValue(String value) {
        mValue = value;
    }

    public String getSerial() {
        return mSerial;
    }

    // Setter for the item value
    public void setSerial(String serial) {
        mSerial = serial;
    }

    // Getter for the date associated with the item
    public Date getDate() {
        return mDate;
    }

    // Setter for the date associated with the item
    public void setDate(Date date) {
        mDate = date;
    }
    public String getPhotoFilename() {
        return "IMG_" + getId().toString() + ".jpg";
    }
}
