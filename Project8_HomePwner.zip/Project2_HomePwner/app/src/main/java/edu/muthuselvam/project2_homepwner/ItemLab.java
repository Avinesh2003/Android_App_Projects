package edu.muthuselvam.project2_homepwner;

import static edu.muthuselvam.project2_homepwner.Item.ITEM_NAMES;
import static edu.muthuselvam.project2_homepwner.Item.ITEM_SERIAL;
import static edu.muthuselvam.project2_homepwner.Item.ITEM_VALUES;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ItemLab {
    private static ItemLab sItemLab; //Setting up the singleton

    private List<Item> mItems; //Setting up List of Crime objects
    private Context mContext;

    //Setting up the singleton - Start
    public static ItemLab get(Context context) {
        if (sItemLab == null) {
            sItemLab = new ItemLab(context);
        }
        return sItemLab;
    }

    public void addItem(Item c) {
        mItems.add(c);
    }

    private ItemLab(Context context) {
        mItems = new ArrayList<>();


        for (int i = 0; i < ITEM_NAMES.length; i++) {
            Item item = new Item();
            item.setName(ITEM_NAMES[i]);
            item.setValue(ITEM_VALUES[i]);
            item.setSerial(ITEM_SERIAL[i]);
            mItems.add(item);
        }
        mContext = context.getApplicationContext();

    }
    public List<Item> getItems() {
        return mItems;
    }

    public Item getItem(UUID id) {
        for (Item item : mItems) {
            if (item.getId().equals(id)) {
                return item;
            }
        }
        return null;
    }
    public File getPhotoFile(Item item) {
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, item.getPhotoFilename());
    }

    public void updateItem(Item item) {
        UUID id = item.getId();
        for (int i = 0; i < mItems.size(); i++) {
            if (mItems.get(i).getId().equals(id)) {
                mItems.set(i, item);
                return;
            }
        }
    }

}
